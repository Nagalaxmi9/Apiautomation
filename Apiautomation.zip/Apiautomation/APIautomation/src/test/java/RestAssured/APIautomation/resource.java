package RestAssured.APIautomation;

public class resource {
	public static String posttwitter1()
	{
		
		return "statuses/update.json";
		
	}
	public static String gettwitter1()
	{
       return "search/tweets.json";
	}
	
	public static String blocktwitter1()
	{

	return "blocks/create.json";
	}
	public static String displaywitter1()
	{
		return "statuses/user_timeline.json";
	 
	}
	public static String weatherwitter1()
	{
		return "search/tweets.json";
	 
	}
	public static String searchwitter1()
	{
		return "search/tweets.json";
	 
	}
	
	public static String fortwitter1()
	{
		return "trends/place.json";
	 
	}
	
	
	

}
